package com.capgemini.contactbook.ui;

import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.logging.Logger;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.service.ContactBookServiceImpl;
import com.capgemini.contactbook.service.IContactBookService;


public class Client {

	static Scanner sc =new Scanner(System.in);
	static  IContactBookService contactBookService=null;
	static ContactBookServiceImpl contactBookServiceImpl=null;
	static Logger logger=Logger.getAnonymousLogger();
	
	
	public static void main(String[] args) throws Exception {
		//PropertyConfigurator.configure("resources/log4j.properties");
		EnquiryBean enquiryBean=null;
		 Integer enquiryId=null;
		  int option=0;// menu option
		  while(true)
		  {
			  System.out.println("***************GLOBAL  RECUIREMENTS ORGANIZATION***************");
			  System.out.println("choose an operation");
			  System.out.println("1.ENTER ENQUIRY DETAILS");// adding 
			  System.out.println("2.view enquiry details on Id"); // view
			  System.out.println("0.exit");
			  System.out.println("******************");
			  System.out.println("select an option");
			  // accept option
			  try
			  {
				  option=sc.nextInt();
				  switch(option)
				  {
				  case 1:
					  while(enquiryBean==null)
					  {
						  enquiryBean=populateEnquiryBean();
					  }
					  try {
							contactBookService =new ContactBookServiceImpl();
							enquiryId = contactBookService.addEnquiry(enquiryBean);

                          	System.out.println("enquiry details successfully inserted");
							System.out.println("enquiry id is"+ enquiryId);
						} 
					  finally {
						 enquiryId=null;
							contactBookService = null;
							enquiryBean = null;
						}

						break;
				  case 2:

						contactBookServiceImpl=new ContactBookServiceImpl();
						System.out.println("enter enqiry id");
						enquiryId=sc.nextInt();
						while(true)
						{
							if(ContactBookServiceImpl.validateEnquiryId(enquiryId))
							{
								break;
							}
							else
							{
								System.err.println("enter a valid  id");
								enquiryId=sc.nextInt();
								
							
					
							}
						}
						enquiryBean=getEnquiryDetails(enquiryId);
								if(enquiryBean!=null)
								{
									System.out.println("fisrt name"+enquiryBean.getfName());
									System.out.println("last name"+ enquiryBean.getlName());
									System.out.println("contact number"+enquiryBean.getContactNo());
									System.out.println("preferred location"+enquiryBean.getpLocation());
									System.out.println("preferred domain"+enquiryBean.getpDomain());
								}
								else
								{
									System.err.println("there is no details regarding with enquiryId"+enquiryId);
								}

						break;
				  case 3:
					  System.out.println("exit application");
					  System.exit(0);
					  break;
				  }
			  }
			  catch (InputMismatchException e) {
					sc.nextLine();
					System.err.println("Please enter a numeric value, try again");
				}

			}// end of while
		}// end of try
			  
			  
			 private static EnquiryBean getEnquiryDetails(Integer enquiryId) throws Exception {
				 EnquiryBean enquiryBean = null;
					contactBookService = new ContactBookServiceImpl();

					enquiryBean = contactBookService.viewEnquiryDetails(enquiryId);

					contactBookService = null;
				 
		// TODO Auto-generated method stub
		return enquiryBean;
	}


		
		  
		
		
		
		
		
		
		
		
	


	private static EnquiryBean populateEnquiryBean() {
		// TODO Auto-generated method stub
		EnquiryBean enquiryBean=new EnquiryBean();
		  System.out.println("enter the details");
		  System.out.println("enter teh first name");
		  enquiryBean.setfName(sc.next());
		  System.out.println("enter teh last name");
		  enquiryBean.setlName(sc.next());
		  System.out.println("enter the contact number");
		  enquiryBean.setContactNo(sc.next());
		  System.out.println("enter preferred location");
			  enquiryBean.setpLocation(sc.next());
			  System.out.println("enter domain");
			  enquiryBean.setpDomain(sc.next());
		  
		return null;
	}

}
