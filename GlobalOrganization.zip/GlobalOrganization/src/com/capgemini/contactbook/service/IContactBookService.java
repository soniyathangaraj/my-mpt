package com.capgemini.contactbook.service;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookException;

public interface IContactBookService {

	 public int addEnquiry(EnquiryBean enquiryBean) throws ContactBookException;

	 public EnquiryBean viewEnquiryDetails(Integer enquiryId) throws ContactBookException, Exception;

	

	


	
}
