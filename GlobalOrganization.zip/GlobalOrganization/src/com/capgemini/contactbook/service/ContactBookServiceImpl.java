package com.capgemini.contactbook.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.dao.IContactBookDao;
import com.capgemini.contactbook.exception.ContactBookException;



public class ContactBookServiceImpl implements IContactBookService {
	IContactBookDao contactBookDao;
	//------------------------ 1. ContactBook  Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	addEnquiry
	 - Input Parameters	:	enquiry bean object
	 - Return Type		:	integer id
	 - Throws			:  	ContactBookException
	 - Author			:	SUGANYA THANGARAJ
	 - Creation Date	:	19/12/2018
	 - Description		:	adding enquiry details to database calls dao method addEnquiry(enquiry bean)
	 * @throws ContactBookException 
	 ********************************************************************************************************/
	

	

	@Override
	public int addEnquiry(EnquiryBean enquiryBean) throws ContactBookException {
		// TODO Auto-generated method stub
		contactBookDao=new ContactBookDaoImpl();	
		int enquirySeq;
		enquirySeq= contactBookDao.addEnquiry(enquiryBean);
		return enquirySeq;
	
	}

	public static boolean validateEnquiryId(Integer enquiryId) {
		// TODO Auto-generated method stub
		return false;
	}
	//------------------------ 1. Donor Application --------------------------
		/*******************************************************************************************************
		 - Function Name	:	viewEnquiryDetails
		 - Input Parameters	:	Integer  enquiryId
		 - Return Type		:	EnquiryBean object
		 - Throws		    :  	ContactBookException
		 - Author		    :	SUGANYA THANGARAJ
		 - Creation Date	:	19/12/2018
		 - Description		:	calls dao method viewEnquiryDetails(enquiryId)
		 * @throws Exception 
		 ********************************************************************************************************/
		
	@Override
	public EnquiryBean viewEnquiryDetails(Integer enquiryId) throws Exception {
		// TODO Auto-generated method stub
		contactBookDao=new ContactBookDaoImpl();
		EnquiryBean bean=null;
		bean=contactBookDao.viewEnquiryDetails(enquiryId);
		return bean;
		
	}
	/*******************************************************************************************************
	 - Function Name	: validateEnquiryDetails(EnquiryBean bean)
	 - Input Parameters	: EnquiryBean bean)
	 - Return Type		: void
	 - Throws		    :contactBookException
	 - Author	      	: SUGANYA THANGARAJ
	 - Creation Date	: 19/12/2018
	 - Description		: validates the EnquiryBean object
	 ********************************************************************************************************/
	public void validateEnquiry(EnquiryBean bean) throws ContactBookException
	{
		List<String> validationErrors = new ArrayList<String>();

		//Validating first name
		if(!(isValidName(bean.getfName()))) {
			validationErrors.add("\n the fisrt  Name Should Be In Alphabets and minimum 3 characters long ! \n");
		}
		
		//Validating Phone Number
		if(!(isValidPhoneNumber(bean.getContactNo()))){
			validationErrors.add("\n Phone Number Should be in 10 digit \n");
		}
		
		
		if(!validationErrors.isEmpty())
			throw new ContactBookException(validationErrors +"");
	}

	public boolean isValidName(String fName){
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(fName);
		return nameMatcher.matches();
	}
	
	
	public boolean isValidPhoneNumber(String contactNo){
		Pattern phonePattern=Pattern.compile("^[1-9]{1}[0-9]{9}$");
		Matcher phoneMatcher=phonePattern.matcher(contactNo);
		return phoneMatcher.matches();
		
	}
	
	public boolean validateEnquiryId(String enquiryId) {
		
		Pattern idPattern = Pattern.compile("[0-9]{1,4}");
		Matcher idMatcher = idPattern.matcher(enquiryId);
		
		if(idMatcher.matches())
			return true;
		else
			return false;		
	}

	
	
}
