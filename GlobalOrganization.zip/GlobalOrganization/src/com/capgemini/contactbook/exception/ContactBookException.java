package com.capgemini.contactbook.exception;

public class ContactBookException extends Exception {
	public ContactBookException( String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
	

}
