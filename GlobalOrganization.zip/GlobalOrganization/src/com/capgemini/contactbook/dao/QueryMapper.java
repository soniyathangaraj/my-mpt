package com.capgemini.contactbook.dao;

public interface QueryMapper {
	public static final String VIEW_ENQUIRY_DETAILS_QUERY="SELECT  first name,last name,contactnumber,domain, city FROM enquiry WHERE  enquiryid=?";
	public static final String INSERT_QUERY="INSERT INTO ENQUIRY VALUES(enquiries_sequence.NEXTVAL,?,?,?,?,?)";
	public static final String ENQUIRYID_QUERY_SEQUENCE="SELECT enquiries_sequence.CURRVAL FROM enquiry";

}
