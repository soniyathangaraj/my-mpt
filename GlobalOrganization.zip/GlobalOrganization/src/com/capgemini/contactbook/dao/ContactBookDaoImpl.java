package com.capgemini.contactbook.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Logger;



import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.util.DBConnection;


public class ContactBookDaoImpl implements IContactBookDao {
	
	
	//Logger logger=Logger.getRootLogger();
	public ContactBookDaoImpl ()
	{
	//PropertyConfigurator.configure("resources//log4j.properties");
	
	}//------------------------ 1. Enquiry Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	addEnquiry(EnquiryBean enquiryBean)
	 - Input Parameters	:	EnquiryBean enquiryBean
	 - Return Type		:	Integer
	 - Throws			:  	ContactBookException
	 - Author			:	SUGANYA THANGARAJ
	 - Creation Date	:	18/11/2016
	 - Description		:	Adding ENQUIRY
	 ********************************************************************************************************/

	@Override
	public int addEnquiry(EnquiryBean enquiryBean) throws ContactBookException {
		// TODO Auto-generated method stub
        Connection connection = DBConnection.getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		Integer enquiryId=null;
		
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

			preparedStatement.setString(1,enquiryBean.getfName());
			preparedStatement.setString(2,enquiryBean.getlName());
			preparedStatement.setString(3,enquiryBean.getContactNo());
			preparedStatement.setString(4,enquiryBean.getpDomain());
			preparedStatement.setString(5,enquiryBean.getpLocation());
			
			
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QueryMapper.ENQUIRYID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				enquiryId=resultSet.getInt(1);
						
			}
	
			if(queryResult==0)
			{
				//logger.error("Insertion failed ");
				throw new ContactBookException("Inserting  enquiry details failed ");

			}
			else
			{
				//logger.info("enquiry details added successfully:");
				return enquiryId;
			}

		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			//Logger.error(sqlException.getMessage());
			throw new ContactBookException("Tehnical problem occured refer log");
		}

		finally
		{
			try 
			{
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				//logger.error(sqlException.getMessage());
				throw new ContactBookException("Error in closing db connection");

			}
		}
	}

	//------------------------ 1. Enquiry Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	viewEnquiryDetails(Integer enquiryId)
	 - Input Parameters	:	enquiryId
	 - Return Type		:	EnquiryBean
	 - Throws			:  	ContactBookException
	 - Author			:	suganya thangaraj
	 - Creation Date	:	18/11/2016
	 - Description		:	ViewEventDetails
	 ********************************************************************************************************/
	@Override
	public EnquiryBean viewEnquiryDetails(Integer enquiryId) throws Exception {
		// TODO Auto-generated method stub
       Connection connection=DBConnection.getConnection();
		
		
		PreparedStatement preparedStatement=null;
		ResultSet resultset = null;
		EnquiryBean bean=null;
		
		try
		{
			preparedStatement=connection.prepareStatement(QueryMapper.VIEW_ENQUIRY_DETAILS_QUERY);
			preparedStatement.setInt(1,enquiryId);
			resultset=preparedStatement.executeQuery();
			
			if(resultset.next())
			{
				bean = new EnquiryBean();
				bean.setfName(resultset.getString(1));
				bean.setlName(resultset.getString(2));
				bean.setContactNo(resultset.getString(3));
				bean.setpDomain(resultset.getString(4));
				bean.setpLocation(resultset.getString(5));
			}
			
			if( bean != null)
			{
				//logger.info("Record Found Successfully");
				return bean;
			}
			else
			{
				//logger.info("Record Not Found Successfully");
				return null;
			}
			
		}
		catch(Exception e)
		{
			//logger.error(e.getMessage());
			throw new ContactBookException(e.getMessage());
		}
		finally
		{
			try 
			{
				resultset.close();
				preparedStatement.close();
				connection.close();
			} 
			catch (SQLException e) 
			{
				//logger.error(e.getMessage());
				throw new ContactBookException("Error in closing db connection");

			}
		}
		
	}

}
