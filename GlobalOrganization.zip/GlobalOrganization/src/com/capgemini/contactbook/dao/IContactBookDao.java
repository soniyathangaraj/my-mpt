package com.capgemini.contactbook.dao;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookException;

public interface IContactBookDao {

	int addEnquiry(EnquiryBean enquiryBean) throws ContactBookException;

	EnquiryBean viewEnquiryDetails(Integer enquiryId) throws ContactBookException, Exception;

}
