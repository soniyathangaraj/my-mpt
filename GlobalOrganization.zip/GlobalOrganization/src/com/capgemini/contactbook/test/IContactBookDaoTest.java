package com.capgemini.contactbook.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.BeforeClass;
import org.junit.jupiter.api.Test;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exception.ContactBookException;




class IContactBookDaoTest {
	static ContactBookDaoImpl dao;
	static EnquiryBean enquiryBean;

	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		dao = new ContactBookDaoImpl  ();
		enquiryBean= new EnquiryBean();
	}

	@Test
	void testAddEnquiry() throws ContactBookException {
		assertNotNull(dao.addEnquiry(enquiryBean));
	}
	/************************************
	 * Test case for addAddDetails()
	 * 
	 ************************************/
	
	@Test
	public void testAddEnquiry2() throws ContactBookException {

		enquiryBean.setfName("suganya");
		enquiryBean.setlName("thangaraj");
		enquiryBean.setContactNo("9578817962");
		enquiryBean.setpDomain("software");
		enquiryBean.setpLocation("chennai");
		
		assertTrue("Data Inserted successfully",
				Integer.(dao.addEnquiry(enquiryBean)) > 1000);

	}
	
	
	

	@Test
	void testViewEnquiryDetails() {
		assertEquals(1001, dao.viewEnquiryDetails(enquiryBean));
		
	}

}
